import customtkinter
from tkinter import filedialog
from tkinter import *


class ToplevelWindow(customtkinter.CTkToplevel):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        customtkinter.set_appearance_mode("dark")
        customtkinter.set_default_color_theme("dark-blue")
        self.geometry("900x600")

        self.label = customtkinter.CTkLabel(self, text="Results")
        self.label.pack(padx=20, pady=20)


def browse_button():
    # Allow user to select a directory and store it in global var
    # called folder_path
    filename = filedialog.askdirectory()
    folder_path.set(filename)
    print(filename)
    label2 = customtkinter.CTkLabel(master=app, text="Dataset address: "+filename, font=("Ariel", 14))
    label2.pack()
    app.button_1.pack(side="top", padx=20, pady=20)


class App(customtkinter.CTk):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        customtkinter.set_appearance_mode("dark")
        customtkinter.set_default_color_theme("dark-blue")
        self.geometry("700x400")
        self.label = customtkinter.CTkLabel(self, text="Recommender System", font=("Ariel", 24))
        self.label.pack(padx=20, pady=20)

        self.button_2 = customtkinter.CTkButton(self, text="Select Dataset", command=browse_button)
        self.button_2.pack(padx=20, pady=20)

        self.button_1 = customtkinter.CTkButton(self, text="Run", command=self.open_toplevel)

        self.toplevel_window = None

    def open_toplevel(self):
        if self.toplevel_window is None or not self.toplevel_window.winfo_exists():
            self.toplevel_window = ToplevelWindow(self)  # create window if its None or destroyed
            self.toplevel_window.focus()
        else:
            self.toplevel_window.focus()  # if window exists focus it


app = App()
folder_path = StringVar()
app.mainloop()
